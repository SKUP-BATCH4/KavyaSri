#include<stdio.h>
int main()
{
    int a=0x07,n=0x07;
    int b=n^a;
    printf("0x%x",b);
}
